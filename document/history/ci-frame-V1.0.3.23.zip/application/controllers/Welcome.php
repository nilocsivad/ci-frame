<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Welcome extends MY_Controller {

	function __construct() {
		parent::__construct();
	}
	
	public function index() {
		$online = $this->session->userdata( parent::ONLINE_KEY );
		$data = array( "is_login", ( empty( $online ) ? false : $online ) );
		$this->load->view( 'welcome', $data );
	}
}
